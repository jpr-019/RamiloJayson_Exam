
// NAVIGATION
$(function () {
  $(document).scroll(function () {
	  var $nav = $(".fixed-top");
	  $nav.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
	  $nav.removeClass('nav-bg-trans', $(this).scrollTop() > $nav.height());


	  var $aside = $(".z-aside");
	  var $h = $(".h");
	  $aside.toggleClass('aside-fixed', $(this).scrollTop() > $h.height());
	  // $aside.removeClass('aside-absolute', $(this).scrollTop() > $h.height());
	});
});


// SLIDER



// CAROUSEL
$('.carousel').carousel({
  
})



// SCROLL
$(document).ready(function() { 
	'use strict';
    $("html").niceScroll({
		cursorcolor: '#D51130',
		cursoropacitymin: '1',
		cursorborder: '0px',
		cursorborderradius: '0px',
		cursorwidth: '5px',
		cursorminheight: 60,
		horizrailenabled: false,
		zindex: 1090
	});
  });


//ANIMATION

$(document).ready(function() {	
	'use strict';
	$('.animated').appear(function() {
		var element = $(this),
			animation = element.data('animation'),
			animationDelay = element.data('animation-delay');
			if ( animationDelay ) {

				setTimeout(function(){
					element.addClass( animation + " visible");
				}, animationDelay);

			} else {
				element.addClass( animation + " visible");
			}
	});
});
	

// SCROLL TOP
$('.back-to-top').click(function(){
    $('html,body').animate({scrollTop: 0}, 2000);
});


// DIV SCROLL

    // $(function () {
    //     $('[data-paroller-factor]').paroller();
    //     $('.paroller').paroller({
    //         factor: 0.4,
    //         type: 'foreground'
    //     });
    //     $('body').scrollspy({target: '#main-navbar'});
    // });



    function equalizeHeight(x, y) {
        var textHeight = $(x).height();
        $(y).css('min-height', textHeight);
    }
    equalizeHeight('.featured-posts .text', '.featured-posts .image');

    $(window).resize(function () {
        equalizeHeight('.featured-posts .text', '.featured-posts .image');
    });
